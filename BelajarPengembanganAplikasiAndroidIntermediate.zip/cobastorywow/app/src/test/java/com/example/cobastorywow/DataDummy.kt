package com.example.cobastorywow

import com.example.cobastorywow.ListStoryItem

object DataDummy {

    fun generateDummyStories(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val quote = ListStoryItem(
                i.toString(),
                "2024-12-07T08:11:48.655Z",
                "lilis",
                "Hi",
                48.856614,
                "event-$i",
                2.352222

            )
            items.add(quote)
        }
        return items
    }
}