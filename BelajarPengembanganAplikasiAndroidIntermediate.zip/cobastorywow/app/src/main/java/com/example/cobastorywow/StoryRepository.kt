package com.example.cobastorywow

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

class StoryRepository {

    private val client = OkHttpClient()

    fun getStoriesWithLocation(callback: (List<Story>?, String?) -> Unit) {
        val request = Request.Builder()
            .url("https://story-api.dicoding.dev/v1/stories?location=1")
            .get()
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                callback(null, "Failed to fetch stories: ${e.message}")
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    val jsonObject = JSONObject(responseBody ?: "{}")
                    val listStory = jsonObject.getJSONArray("listStory")

                    val stories = mutableListOf<Story>()
                    for (i in 0 until listStory.length()) {
                        val storyJson = listStory.getJSONObject(i)
                        val story = Story(
                            id = storyJson.getString("id"),
                            name = storyJson.getString("name"),
                            description = storyJson.optString("description", ""),
                            photoUrl = storyJson.getString("photoUrl"),
                            lat = storyJson.getDouble("lat"),
                            lon = storyJson.getDouble("lon")
                        )
                        stories.add(story)
                    }
                    callback(stories, null)
                } else {
                    callback(null, "Failed to load data: ${response.message}")
                }
            }
        })
    }
}
