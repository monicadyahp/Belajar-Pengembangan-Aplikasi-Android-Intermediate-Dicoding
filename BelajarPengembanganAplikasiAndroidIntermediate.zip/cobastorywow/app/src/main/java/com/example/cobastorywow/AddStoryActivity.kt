package com.example.cobastorywow

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.cobastorywow.databinding.ActivityAddStoryBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.Task
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class AddStoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddStoryBinding
    private var selectedPhotoUri: Uri? = null
    private var photoFile: File? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var latitude: Double? = null
    private var longitude: Double? = null
    private var includeLocation: Boolean = true

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                selectedPhotoUri = uri
                val processedFile = processGalleryImage(uri)
                if (processedFile != null) {
                    photoFile = processedFile
                    binding.ivSelectedPhoto.setImageURI(uri)
                    binding.ivSelectedPhoto.visibility = View.VISIBLE
                } else {
                    Toast.makeText(this, "Failed to process selected image", Toast.LENGTH_SHORT).show()
                }
            }
        }

    private val takePictureLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                val processedFile = processCameraImage(Uri.fromFile(photoFile))
                if (processedFile != null) {
                    selectedPhotoUri = Uri.fromFile(processedFile)
                    photoFile = processedFile
                    binding.ivSelectedPhoto.setImageURI(selectedPhotoUri)
                    binding.ivSelectedPhoto.visibility = View.VISIBLE
                } else {
                    Toast.makeText(this, "Failed to process camera image", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Failed to take photo", Toast.LENGTH_SHORT).show()
            }
        }

    private val CAMERA_PERMISSION_REQUEST_CODE = 101
    private val LOCATION_PERMISSION_REQUEST_CODE = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        binding.switchIncludeLocation.setOnCheckedChangeListener { _, isChecked ->
            includeLocation = isChecked
        }

        binding.buttonSelectPhoto.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        binding.buttonTakePhoto.setOnClickListener {
            if (checkCameraPermission()) {
                photoFile = createTempFile()
                val photoUri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.provider",
                    photoFile!!
                )
                takePictureLauncher.launch(photoUri)
            } else {
                requestCameraPermission()
            }
        }

        binding.buttonAdd.setOnClickListener {
            val description = binding.edAddDescription.text.toString()
            if (description.isBlank()) {
                Toast.makeText(this, "Please provide a description", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val photoUri = selectedPhotoUri
            if (photoUri == null) {
                Toast.makeText(this, "Please select or take a photo", Toast.LENGTH_SHORT).show()
            } else {
                val file = photoFile ?: getFileFromUri(photoUri)
                if (file != null) {
                    if (includeLocation) {
                        getLocation {
                            uploadStory(description, file)
                        }
                    } else {
                        uploadStory(description, file)
                    }
                } else {
                    Toast.makeText(this, "Failed to retrieve photo file", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun checkCameraPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.CAMERA)) {
                AlertDialog.Builder(this)
                    .setMessage("We need camera permission to take photos.")
                    .setPositiveButton("OK") { _, _ ->
                        ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                getLocation {}
            } else {
                Toast.makeText(this, "Location permission is required to upload stories with location", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                photoFile = createTempFile()
                val photoUri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.provider",
                    photoFile!!
                )
                takePictureLauncher.launch(photoUri)
            } else {
                Toast.makeText(this, "Camera permission is needed to take photos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun getLocation(callback: () -> Unit) {
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            fusedLocationClient.lastLocation.addOnCompleteListener { task: Task<Location> ->
                val location = task.result
                if (location != null) {
                    latitude = location.latitude
                    longitude = location.longitude
                }
                callback()
            }
        }
    }

    private fun createTempFile(): File {
        val storageDir: File? = externalCacheDir
        return File.createTempFile(
            "temp_photo_",
            ".jpg",
            storageDir
        ).apply {
            createNewFile()
        }
    }

    private fun getFileFromUri(uri: Uri): File? {
        return try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                it.moveToFirst()
                val index = it.getColumnIndex(MediaStore.Images.Media.DATA)
                val filePath = it.getString(index)
                File(filePath)
            }
        } catch (e: Exception) {
            Log.e("AddStoryActivity", "Error resolving URI: ${e.message}")
            null
        }
    }

    private fun processGalleryImage(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)

            val resizedBitmap = resizeBitmap(bitmap, maxWidth = 1080, maxHeight = 1080)

            val tempFile = File.createTempFile("processed_gallery_image", ".jpg", cacheDir)
            val outputStream = FileOutputStream(tempFile)
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
            outputStream.flush()
            outputStream.close()

            if (tempFile.length() > 10 * 1024 * 1024) {
                Toast.makeText(this, "File terlalu besar untuk diunggah", Toast.LENGTH_SHORT).show()
                return null
            }

            tempFile
        } catch (e: Exception) {
            Log.e("AddStoryActivity", "Error processing gallery image: ${e.message}")
            null
        }
    }

    private fun processCameraImage(uri: Uri): File? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)

            val resizedBitmap = resizeBitmap(bitmap, maxWidth = 1080, maxHeight = 1080)

            val tempFile = File.createTempFile("processed_camera_image", ".jpg", cacheDir)
            val outputStream = FileOutputStream(tempFile)
            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
            outputStream.flush()
            outputStream.close()

            if (tempFile.length() > 10 * 1024 * 1024) {
                Toast.makeText(this, "File terlalu besar untuk diunggah", Toast.LENGTH_SHORT).show()
                return null
            }

            tempFile
        } catch (e: Exception) {
            Log.e("AddStoryActivity", "Error processing camera image: ${e.message}")
            null
        }
    }

    private fun resizeBitmap(bitmap: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        val aspectRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val newWidth = if (bitmap.width > bitmap.height) maxWidth else (maxHeight * aspectRatio).toInt()
        val newHeight = if (bitmap.width > bitmap.height) (maxWidth / aspectRatio).toInt() else maxHeight

        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, false)
    }

    private fun uploadStory(description: String, file: File) {
        binding.progressBar.visibility = View.VISIBLE

        val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", null)

        if (token == null) {
            Toast.makeText(this, "Authentication token is missing", Toast.LENGTH_SHORT).show()
            binding.progressBar.visibility = View.GONE
            return
        }

        if (!file.exists() || !file.canRead()) {
            Toast.makeText(this, "Photo file cannot be read", Toast.LENGTH_SHORT).show()
            binding.progressBar.visibility = View.GONE
            return
        }

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("description", description)
            .addFormDataPart(
                "photo",
                file.name,
                file.asRequestBody("image/jpeg".toMediaType())
            )
            .apply {
                latitude?.let { addFormDataPart("lat", it.toString()) }
                longitude?.let { addFormDataPart("lon", it.toString()) }
            }
            .build()

        val request = Request.Builder()
            .url("https://story-api.dicoding.dev/v1/stories")
            .addHeader("Authorization", "Bearer $token")
            .post(requestBody)
            .build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@AddStoryActivity, "Failed to upload story: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        Toast.makeText(this@AddStoryActivity, "Story added successfully", Toast.LENGTH_SHORT).show()

                        val intent = Intent()
                        intent.putExtra("refreshNeeded", true)
                        setResult(RESULT_OK, intent)

                        finish()
                    } else {
                        Toast.makeText(this@AddStoryActivity, "Failed to upload story", Toast.LENGTH_LONG).show()
                    }
                }
            }
        })
    }
}