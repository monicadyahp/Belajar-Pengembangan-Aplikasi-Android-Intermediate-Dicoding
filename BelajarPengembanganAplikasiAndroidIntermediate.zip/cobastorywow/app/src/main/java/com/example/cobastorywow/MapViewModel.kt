package com.example.cobastorywow

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MapViewModel(private val repository: StoryRepository) : ViewModel() {
    private val _stories = MutableLiveData<List<Story>>()
    val stories: LiveData<List<Story>> get() = _stories
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> get() = _errorMessage
    fun setStories(stories: List<Story>) {
        _stories.value = stories
    }
    fun setError(message: String) {
        _errorMessage.value = message
    }
    fun fetchStoriesWithLocation() {
         }
    }

