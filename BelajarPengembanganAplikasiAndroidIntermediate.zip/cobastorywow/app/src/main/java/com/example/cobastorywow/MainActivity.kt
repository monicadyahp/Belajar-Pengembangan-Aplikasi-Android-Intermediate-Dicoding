package com.example.cobastorywow

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cobastorywow.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: PagingViewModel by viewModels {
        PagingViewModelFactory(StoryPagingRepository(StoryApiService.create()))
    }
    private lateinit var storyPagingAdapter: StoryPagingAdapter

    private var refreshNeeded: Boolean = false

    companion object {
        private const val ADD_STORY_REQUEST_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", null)

        if (token.isNullOrEmpty()) {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()

        lifecycleScope.launch {
            viewModel.getStoriesPaging(token).collectLatest { pagingData ->
                storyPagingAdapter.submitData(pagingData)
            }
        }

        observeAdapterLoadingState()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        storyPagingAdapter = StoryPagingAdapter { story -> onStoryClicked(story) }
        binding.rvStories.layoutManager = LinearLayoutManager(this)
        binding.rvStories.adapter = storyPagingAdapter

        binding.swipeRefreshLayout.setOnRefreshListener {
            refreshData()
            binding.swipeRefreshLayout.isRefreshing = false
        }
    }

    private fun observeAdapterLoadingState() {
        storyPagingAdapter.addLoadStateListener { loadStates ->
            val isLoading = loadStates.source.refresh is androidx.paging.LoadState.Loading
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    private fun onStoryClicked(story: ListStoryItem) {
        val intent = Intent(this, StoryDetailActivity::class.java).apply {
            putExtra("storyId", story.id)
            putExtra("storyName", story.name)
            putExtra("storyDescription", story.description)
            putExtra("storyPhotoUrl", story.photoUrl)
        }
        startActivity(intent)
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)     }

    private fun setupClickListeners() {

        binding.buttonOpenMap.setOnClickListener {
            val intent = Intent(this, MapActivity::class.java)
            startActivity(intent)
        }

        binding.buttonAddStory.setOnClickListener {
            val intent = Intent(this, AddStoryActivity::class.java)
            startActivityForResult(intent, ADD_STORY_REQUEST_CODE)
        }

        binding.actionLogout.setOnClickListener {
            val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
            with(sharedPreferences.edit()) {
                clear()
                apply()
            }

            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)

            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)

            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_STORY_REQUEST_CODE && resultCode == RESULT_OK) {
            refreshNeeded = data?.getBooleanExtra("refreshNeeded", false) == true
        }
    }

    override fun onResume() {
        super.onResume()
        if (refreshNeeded) {
            refreshData()
            refreshNeeded = false
        }
    }

    private fun refreshData() {
        lifecycleScope.launch {
            val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
            val token = sharedPreferences.getString("TOKEN", null) ?: ""

            viewModel.getStoriesPaging(token).collectLatest { pagingData ->
                storyPagingAdapter.submitData(pagingData)
            }
        }
    }
}
