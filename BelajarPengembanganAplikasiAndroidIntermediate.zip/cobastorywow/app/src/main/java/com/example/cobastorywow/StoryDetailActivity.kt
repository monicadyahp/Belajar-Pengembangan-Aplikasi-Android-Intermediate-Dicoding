package com.example.cobastorywow

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class StoryDetailActivity : AppCompatActivity() {

    private lateinit var ivDetailPhoto: ImageView
    private lateinit var pbLoading: ProgressBar
    private lateinit var tvDetailName: TextView
    private lateinit var tvDetailDescription: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story_detail)

        ivDetailPhoto = findViewById(R.id.iv_detail_photo)
        pbLoading = findViewById(R.id.pb_loading)
        tvDetailName = findViewById(R.id.tv_detail_name)
        tvDetailDescription = findViewById(R.id.tv_detail_description)

        val storyId = intent.getStringExtra("storyId")
        val storyName = intent.getStringExtra("storyName")
        val storyDescription = intent.getStringExtra("storyDescription")
        val storyPhotoUrl = intent.getStringExtra("storyPhotoUrl")

        Log.d(
            "StoryDetailActivity",
            "Received data - storyId: $storyId, storyName: $storyName, storyDescription: $storyDescription, storyPhotoUrl: $storyPhotoUrl"
        )

        if (storyId != null && storyName != null && storyDescription != null && storyPhotoUrl != null) {
            tvDetailName.text = storyName
            tvDetailDescription.text = storyDescription

            pbLoading.visibility = View.VISIBLE
            loadImageWithPicasso(storyPhotoUrl)

            fetchStoryDetails(storyId)
        } else {
            Toast.makeText(this, "Missing story data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadImageWithPicasso(imageUrl: String) {
        Picasso.get()
            .load(imageUrl)
            .into(ivDetailPhoto, object : com.squareup.picasso.Callback {
                override fun onSuccess() {
                    pbLoading.visibility = View.GONE
                    Log.d("PicassoCallback", "Image loaded successfully")
                }

                override fun onError(e: Exception?) {
                    pbLoading.visibility = View.GONE
                    Log.e("PicassoCallback", "Error loading image", e)
                    Toast.makeText(this@StoryDetailActivity, "Error loading image", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun fetchStoryDetails(storyId: String) {
        val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", null)

        if (token == null) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show()
            return
        }

        val client = OkHttpClient()

        val request = Request.Builder()
            .url("https://story-api.dicoding.dev/v1/stories/$storyId")
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("StoryDetailActivity", "Error fetching story details", e)
                runOnUiThread {
                    Toast.makeText(
                        this@StoryDetailActivity,
                        "Failed to fetch story details",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    Log.d("StoryDetailActivity", "Story Details Response: $responseBody")

                    if (responseBody != null) {
                        try {
                            val jsonObject = JSONObject(responseBody)

                            val storyObject = jsonObject.getJSONObject("story")
                            val storyName = storyObject.getString("name")
                            val storyDescription = storyObject.getString("description")
                            val storyPhotoUrl = storyObject.getString("photoUrl")

                            runOnUiThread {
                                tvDetailName.text = storyName
                                tvDetailDescription.text = storyDescription

                                if (storyPhotoUrl != ivDetailPhoto.tag) {
                                    pbLoading.visibility = View.VISIBLE
                                    loadImageWithPicasso(storyPhotoUrl)
                                    ivDetailPhoto.tag = storyPhotoUrl
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("StoryDetailActivity", "Error parsing the story details", e)
                            runOnUiThread {
                                Toast.makeText(
                                    this@StoryDetailActivity,
                                    "Error parsing story details",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                } else {
                    Log.e("StoryDetailActivity", "Failed to fetch story details")
                    runOnUiThread {
                        Toast.makeText(
                            this@StoryDetailActivity,
                            "Failed to fetch story details",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        })
    }

    override fun onBackPressed() {
        super.onBackPressed()

        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
    }
}
