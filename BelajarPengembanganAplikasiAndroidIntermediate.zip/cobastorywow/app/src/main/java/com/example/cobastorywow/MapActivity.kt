package com.example.cobastorywow

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.MapStyleOptions
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var progressBar: ProgressBar

    private val viewModel: MapViewModel by lazy {
        ViewModelProvider(this, ViewModelFactory(StoryRepository())).get(MapViewModel::class.java)
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            setUpMap()
        } else {
            Toast.makeText(this, "Permission denied. Cannot show location.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        progressBar = findViewById(R.id.progressBar)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            setUpMap()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        observeViewModel()

        findViewById<Button>(R.id.btnChangeMapStyle).setOnClickListener {
            changeMapStyle()
        }
    }

    private fun setUpMap() {
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun observeViewModel() {
        viewModel.stories.observe(this) { stories ->
            progressBar.visibility = ProgressBar.GONE

            stories.forEach { story ->
                val lat = story.lat
                val lon = story.lon
                if (lat != null && lon != null) {
                    val location = LatLng(lat, lon)
                    mMap.addMarker(
                        MarkerOptions()
                            .position(location)
                            .title(story.name)
                            .snippet(story.description)
                    )
                }
            }

            stories.find { it.lat != null && it.lon != null }?.let { firstStory ->
                val firstLocation = LatLng(firstStory.lat!!, firstStory.lon!!)
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(firstLocation, 10f))
            }
        }

        viewModel.errorMessage.observe(this) { errorMessage ->
            progressBar.visibility = ProgressBar.GONE
            errorMessage?.let {
                if (it.contains("Unauthorized", true)) {
                    handleUnauthorizedError()
                } else {
                    Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun handleUnauthorizedError() {
        Toast.makeText(this, "Session expired or Unauthorized access. Please login again.", Toast.LENGTH_SHORT).show()

        val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.remove("TOKEN")
        editor.apply()

        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        progressBar.visibility = ProgressBar.VISIBLE

        setMapStyle(R.raw.map_style)

        fetchStoriesWithLocation()
    }

    private fun fetchStoriesWithLocation() {
        val sharedPreferences = getSharedPreferences("APP_PREFS", MODE_PRIVATE)
        val token = sharedPreferences.getString("TOKEN", null)

        if (token == null) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show()
            return
        }

        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://story-api.dicoding.dev/v1/stories?location=1")
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    progressBar.visibility = ProgressBar.GONE
                    Toast.makeText(this@MapActivity, "Failed to fetch stories", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    val jsonObject = JSONObject(responseBody ?: "{}")
                    val listStories = jsonObject.getJSONArray("listStory")

                    val stories = mutableListOf<Story>()
                    for (i in 0 until listStories.length()) {
                        val storyJson = listStories.getJSONObject(i)
                        val story = Story(
                            id = storyJson.getString("id"),
                            name = storyJson.getString("name"),
                            description = storyJson.optString("description", ""),
                            photoUrl = storyJson.optString("photoUrl", ""),
                            lat = storyJson.optDouble("lat", Double.NaN).takeIf { !it.isNaN() },
                            lon = storyJson.optDouble("lon", Double.NaN).takeIf { !it.isNaN() }
                        )
                        stories.add(story)
                    }

                    runOnUiThread {
                        viewModel.setStories(stories)
                    }
                } else {
                    runOnUiThread {
                        progressBar.visibility = ProgressBar.GONE
                        if (response.code == 401) {
                            handleUnauthorizedError()
                        } else {
                            Toast.makeText(this@MapActivity, "Failed to fetch stories", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        })
    }

    private fun setMapStyle(styleRes: Int) {
        try {
            val success = mMap.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(this, styleRes)
            )
            if (!success) {
                Toast.makeText(this, "Failed to apply map style.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Resources.NotFoundException) {
            Toast.makeText(this, "Style resource not found.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeMapStyle() {
        val currentStyle = mMap.mapType
        mMap.mapType = when (currentStyle) {
            GoogleMap.MAP_TYPE_NORMAL -> GoogleMap.MAP_TYPE_SATELLITE
            GoogleMap.MAP_TYPE_SATELLITE -> GoogleMap.MAP_TYPE_TERRAIN
            GoogleMap.MAP_TYPE_TERRAIN -> GoogleMap.MAP_TYPE_HYBRID
            else -> GoogleMap.MAP_TYPE_NORMAL
        }
        Toast.makeText(
            this,
            "Map type changed to ${getMapTypeName(mMap.mapType)}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun getMapTypeName(mapType: Int): String {
        return when (mapType) {
            GoogleMap.MAP_TYPE_NORMAL -> "Normal"
            GoogleMap.MAP_TYPE_SATELLITE -> "Satellite"
            GoogleMap.MAP_TYPE_TERRAIN -> "Terrain"
            GoogleMap.MAP_TYPE_HYBRID -> "Hybrid"
            else -> "Unknown"
        }
    }
}
