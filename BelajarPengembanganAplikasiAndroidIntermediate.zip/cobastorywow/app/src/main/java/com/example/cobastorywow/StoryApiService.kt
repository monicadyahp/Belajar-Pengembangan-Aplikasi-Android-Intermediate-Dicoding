package com.example.cobastorywow

import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface StoryApiService {
    @GET("stories")
    suspend fun getStories(
        @Header("Authorization") token: String,
        @Query("page") page: Int,
        @Query("size") size: Int
    ): StoryResponse

    companion object {
        fun create(): StoryApiService {
            return RetrofitInstance.retrofit.create(StoryApiService::class.java)
        }
    }
}
